--- STEAMODDED HEADER
--- MOD_NAME: Ghost Perkeo
--- MOD_ID: GhostPerkeo
--- MOD_AUTHOR: [DeBread]
--- MOD_DESCRIPTION: Replaces Perkeo texture with Ghost.

----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.BobandBosip()
    local fancy_mod = SMODS.findModByID("GhostPerkeo")
    local sprite_enhancer = SMODS.Sprite:new("Joker", fancy_mod.path, "Jokers.png", 71, 95, "asset_atli")

    sprite_enhancer:register()
end

----------------------------------------------
------------MOD CODE END----------------------