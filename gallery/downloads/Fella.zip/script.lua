local lift = require("Lift")

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
local model = models.model.root

model.LeftArm.Buddy:setVisible(false)

local timezoneOffsetHours = -5
function getLocalTime()
    local millis = client.getSystemTime()
    local totalSeconds = millis / 1000
    local secondsToday = (totalSeconds + (timezoneOffsetHours * 3600)) % 86400

    local hour24 = math.floor(secondsToday / 3600)
    local minute = math.floor((secondsToday % 3600) / 60)

    local ampm = "AM"
    local hour12 = hour24

    if hour24 >= 12 then
        ampm = "PM"
    end
    if hour24 == 0 then
        hour12 = 12
    elseif hour24 > 12 then
        hour12 = hour24 - 12
    end

    return string.format("%02d:%02d%s", hour12, minute, ampm)
end

-- TEXT TASK

local config = {
    blinkDuration = 2,
    
    scaleChangeStep = 0.25,

    nameplates = {
        list = {
            text = 'Fella',
            color = '#af7aff',
            bold = true
        },
        entity = {
            -- {
            --     text = 'Top text',
            -- },
            {
                text = "Fella",
                bold = true,
                color = "#4f3a73"
            },
            {
                text = " :raccoon:",
                bold = false
            },
        },
        chat = {
            {
                text = ':raccoon:'
            },
            {
                text = ' Fella',
                bold = true,
                color = '#4f3a73',

                hoverEvent = {
                    action = 'show_text',
                    contents = {
                        {
                            text = 'Fella',
                            bold = true,
                        },
                        {
                            text = '                 @notdebread',
                            color = 'dark_gray',
                            bold = false,
                            italic = true
                        },
                        {
                            text = '\nYour local raccoon guy',
                            bold = false
                        },
                        {
                            text = "\n\nIt is [" .. getLocalTime() .. "] for me right now!",
                            bold = false
                        },
                        {
                            text = "\n\nVisit my website!",
                            italic = true,
                            bold = false
                        },
                        {
                            text = "\ndebread.space",
                            color = "gold",
                            bold = false
                        }
                    }
                }
            }
        }
    }
}

local ticks = 0
local lastInput = 0
local lastBlinkTick = 0
local isBlinking = false
local lastHurtTick = 0
local armorShown = false
local glassesShown = true

local tail = {
    xOffset = 45,
    targetXOffset = 45,
    xConditionModifier = 0,

    yOffset = 0,
    layerYOffset = 0,

    wagSpeedMult = 1,
    wagSize = 1
}

local size = {x=1,y=1,z=1}

local clothingActions = {}
local emotionActions = {}
local sizeActions = {}
local selectedEmotion = 'Default'
local emotions = {
    'Default',
    'Tired',
    'Worried',
    'Surprised',
    'Guilty',
    'Flabbergasted'
}

--UPDATE EMOTION
function pings.updateEmotion(id)
    selectedEmotion = id
    for i, v in ipairs(emotionActions) do
        if v:getTitle() == id then
            v:setColor(0,255,0)
            v:setHoverColor(0.5,1,0.5)
        else
            v:setColor(0,0,0)
            v:setHoverColor(100,100,100)
        end
    end

    local index = indexOf(emotions, id)
    model.Head.Eyes:setUVPixels(0,(index-1)*3)
end

--UPDATE CLOTHING
function pings.updateClothing(id)
    for i, v in ipairs(clothingActions) do
        if v:getTitle() == id then
            v:setColor(0,255,0)
            v:setHoverColor(0.5,1,0.5)
        else
            v:setColor(0,0,0)
            v:setHoverColor(100,100,100)
        end
    end

    local targetTexture = textures['model.Skin'..id]
    models.model.root:setPrimaryTexture('CUSTOM',targetTexture)

    --Fix objects that dont use the skin texture
    model.LeftArm.Buddy:setPrimaryTexture('CUSTOM', textures['model.buddy'])

    if player:isLoaded() then    
        for i = 0, 50 do
            particles:newParticle(
                "cloud 1 0 1 1", 
                vec(
                player:getPos()[1]+math.random(-5,5)/10,
                player:getPos()[2]+math.random(0,20)/10,
                player:getPos()[3]+math.random(-5,5)/10
                ),
                vec(
                    math.random(-100,100)/1000,
                    math.random(-100,100)/1000,
                    math.random(-100,100)/1000
                )
            )
        end
    end
end

--UPDATE SIZE
function pings.updateSize()
    model:setScale(size.x,size.y,size.z)
    local EYE_HEIGHT = 1.62

    renderer:setEyeOffset(0, EYE_HEIGHT * (size.y - 1), 0)
    renderer:setOffsetCameraPivot(0, EYE_HEIGHT * (size.y - 1), 0)
end

--UPDATE VISIBLE ARMOR
function pings.updateArmor(state) 
    armorShown = state
    vanilla_model.ARMOR:setVisible(armorShown)
end

function pings.updateGlasses(state)
    glassesShown = state
    model.Head.Glasses:setVisible(glassesShown)
end

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()

end

--tick event, called 20 times per second
function events.tick()
    --Blink
    if ticks % 30 == 0 and math.random(1,4) == 1 and not isBlinking and not includes({"Tired"}, selectedEmotion) then
        model.Head.Eyes:setVisible(false)
        lastBlinkTick = ticks
        isBlinking = true
    end

    if ticks - lastBlinkTick >= config.blinkDuration and isBlinking then
        model.Head.Eyes:setVisible(true)
        isBlinking = false
    end

    if ticks % 20 == 0 then
        pings.updateNameplate()
    end

    if player:getNbt().HurtTime > 0 then
        lastHurtTick = ticks
        vanilla_model.ARMOR:setVisible(true)
    end

    if ticks - lastHurtTick > 200 and vanilla_model.ARMOR:getVisible() and not armorShown then
      vanilla_model.ARMOR:setVisible(false)
    end

    ticks = ticks + 1
end

function events.KEY_PRESS(key, action) 
    if key == 67 then -- the keycode for the 'C', not kidding
        if action == 1 and includes({"Default","Guilty"},selectedEmotion) then --keydown
            pings.setSquint(true)
        elseif action == 0 then --keyup
            pings.setSquint(false)
        end
    end

    if key == 66 and action == 0 then
        action_wheel:setPage('main')
    end

    if getAFKTime().seconds >= 60 then
        print('Welcome back! You were AFK for ' .. getAFKTime().format)
    end

    lastInput = ticks
end


-- function events.KEY_PRESS(key, action)
--     pings.cigar(key,action)
-- end

-- local keyState = 2
-- function pings.cigar(key, action)
--     if key == 67 then
--         if action == 0 then
--             -- models.model.root.Head.cigar:setVisible(false)
--         else
--             -- models.model.root.Head.cigar:setVisible(true)

--             if player:isLoaded() and keyState ~= action then
--                 sounds:playSound("entity.generic.explode", player:getPos(), 1, 1)
--             end
--         end

--         if keyState ~= 2 then
--             keyState = action
--         end
--     end
-- end

--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
    model.Body.Tail:setRot(
        vec(
        tail.xOffset,
        tail.yOffset,
        0)
    )

    model.Body.Tail.TailLayer:setRot(
        vec(
        0,
        tail.layerYOffset,
        0)
    )

    tail.yOffset = math.sin((ticks + delta) * tail.wagSpeedMult / 10) * 10 * tail.wagSize
    tail.layerYOffset = math.sin((ticks + delta - (50 + tail.wagSpeedMult)) * tail.wagSpeedMult / 10) * 2 * tail.wagSize

    if player:isGliding() or player:getPose() == "SWIMMING" then --Swimming / Flying
        tail.xConditionModifier = 25
        tail.wagSpeedMult = 1
        tail.wagSize = 1
    elseif player:isSprinting() then --Sprinting
        tail.xConditionModifier = -50
        tail.wagSpeedMult = 5
        tail.wagSize = 2
    elseif isWalking() then --Walking
        tail.xConditionModifier = -40
        tail.wagSpeedMult = 3
        tail.wagSize = 1.5
    elseif player:getVehicle() ~= nil then
        tail.xConditionModifier = -40
        tail.wagSpeedMult = 1
        tail.wagSize = 1
    else
        tail.xConditionModifier = 0
        tail.wagSpeedMult = 1
        tail.wagSize = 1
    end

    tail.targetXOffset = 45 + math.max(math.min(player:getVelocity()[2] * 100 + tail.xConditionModifier, 10), -75)
    tail.xOffset = tail.xOffset + (tail.targetXOffset - tail.xOffset) * 0.025
end

function events.skull_render(delta, block, item, entity, mode)
    local pos
    if mode == 'HEAD' then
        pos = {0,7,0}
    else
        pos = {0,0,0}
    end
    
    --WHY IS IT MAKING ME DO THIS
    models.model.Skull.SkullHead:setPos(pos[1],pos[2],pos[3])
    models.model.Skull.SkullBody:setPos(pos[1],pos[2],pos[3])
    models.model.Skull.SkullArms:setPos(pos[1],pos[2],pos[3])
    models.model.Skull.SkullLegs:setPos(pos[1],pos[2],pos[3])
end

function events.chat_receive_message(raw, text)
    if host:isHost() then
        local message = string.lower(raw)
        if player:isLoaded() and (message:find('debread') or message:find('fella') or message:find('notdebread')) then
            sounds:playSound("block.note_block.pling", player:getPos(), 1, 2)
        end
    end
end

function events.item_render(item)
    if item:getName() == "TungTung" then
        return models.model.ItemTung 
    end
end

function includes(array, value)
    local foundValue = false
    for i, v in ipairs(array) do
        if v:find(value) then
            foundValue = true
            break
        end
    end

    return foundValue
end

function indexOf(array, value) 
    for i, v in ipairs(array) do
        if value == v then
            return i
        end
    end

    return nil
end

--Non-core functions

function pings.setSquint(value)
    if value then
        model.Head.Eyes:setScale(1, 0.5, 1)
    else 
        model.Head.Eyes:setScale(1, 1, 1)
    end
end

function isWalking()
    return math.abs(player:getVelocity()[1]) >= 0.05 or math.abs(player:getVelocity()[3]) >= 0.05
end

function getAFKTime()
    local time = (ticks - lastInput) / 20
    local formatted = string.format("%02d:%02d", math.floor(time / 60), math.floor(time % 60))
    return {seconds=time, format=formatted}
end

function pings.updateNameplate()
    --Name that appears above the player
    -- nameplate.ENTITY:setText(toJson({
    --     {
    --     text = "Fella",
    --     bold = true,
    --     color = "#4f3a73"
    --     },
    --     {
    --     text = " :raccoon:",
    --     bold = false
    --     },
    -- }))

    nameplate.ENTITY:setOutline(true)
    nameplate.ENTITY:setOutlineColor(40 / 255, 31 / 255, 74 / 255)

    --Name that appears in the tablist
    nameplate.ENTITY:setText(toJson(config.nameplates.entity))
    nameplate.LIST:setText(toJson(config.nameplates.list))
    nameplate.CHAT:setText(toJson(config.nameplates.chat))
end

--Action wheel stuff

--MAIN PAGE ACTIONS

local mainPage = action_wheel:newPage('main')
action_wheel:setPage(mainPage)

local buddyAction = mainPage:newAction()
    :title('Show Buddy')
    :setTexture(textures['model.icons'], 32, 48, 16, 16)
    :onToggle(function (state, self)
        model.LeftArm.Buddy:setVisible(state)

        if state then
            model.LeftArm:setParentType("HEAD")
            model.LeftArm:setOffsetRot(vec(90,0,0))
        else
            model.LeftArm:setParentType("LeftArm")
            model.LeftArm:setOffsetRot(vec(0,0,0))
        end
    end)

local emotionAction = mainPage:newAction()
    :title("Change Emotion...")
    :setTexture(textures['model.icons'],0,0, 16, 16)
    :onLeftClick(function()
        action_wheel:setPage('emotion')
    end)

    
local clothingAction = mainPage:newAction()
    :title("Change Clothing...")
    :setTexture(textures['model.icons'],0,16, 16, 16)
    :onLeftClick(function()
        action_wheel:setPage('clothing')
    end)

local sizeAction = mainPage:newAction()
    :title("Change Size...")
    :setTexture(textures['model.icons'],0,48, 16, 16)
    :onLeftClick(function()
        action_wheel:setPage('size')
    end)

local armorAction = mainPage:newAction()
    :title("Show armor")
    :setTexture(textures['model.icons'],16,48, 16, 16)
    :onToggle(function(state)
        pings.updateArmor(state)
    end)

local glassesAction = mainPage:newAction()
    :title("Show glasses")
    :setTexture(textures['model.icons'],48,48, 16, 16)
    :onToggle(function(state)
        pings.updateGlasses(state)
    end)
    :setToggled(true)

--EMOTION ACTIONS
local emotionPage = action_wheel:newPage('emotion')
table.insert(emotionActions, emotionPage:newAction()
    :title("Default")
    :setTexture(textures['model.icons'],0,0, 16, 16)
    :setColor(0,255,0)
    :setHoverColor(0.5,1,0.5)
    :onLeftClick(function()
        pings.updateEmotion('Default')
    end))
    
table.insert(emotionActions, emotionPage:newAction()
    :title("Tired")
    :setTexture(textures['model.icons'],16,0, 16, 16)
    :onLeftClick(function()
        pings.updateEmotion('Tired')
    end))

table.insert(emotionActions, emotionPage:newAction()
    :title("Worried")
    :setTexture(textures['model.icons'],32,0, 16, 16)
    :onLeftClick(function()
        pings.updateEmotion('Worried')
    end))

table.insert(emotionActions, emotionPage:newAction()
    :title("Surprised")
    :setTexture(textures['model.icons'],48,0, 16, 16)
    :onLeftClick(function()
        pings.updateEmotion('Surprised')
    end))

table.insert(emotionActions, emotionPage:newAction()
    :title("Guilty")
    :setTexture(textures['model.icons'],64,0, 16, 16)
    :onLeftClick(function()
        pings.updateEmotion('Guilty')
    end))

table.insert(emotionActions, emotionPage:newAction()
    :title("Flabbergasted")
    :setTexture(textures['model.icons'],80,0, 16, 16)
    :onLeftClick(function()
        pings.updateEmotion('Flabbergasted')
    end))


--CLOTHING ACTIONS
local clothingPage = action_wheel:newPage('clothing')

table.insert(clothingActions, clothingPage:newAction()
    :title("Default")
    :setTexture(textures['model.icons'],0,16, 16, 16)
    :setColor(0,255,0)
    :setHoverColor(0.5,1,0.5)
    :onLeftClick(function()
        pings.updateClothing('Default')
    end))

table.insert(clothingActions, clothingPage:newAction()
    :title("Business")
    :setTexture(textures['model.icons'],16,16, 16, 16)
    :onLeftClick(function()
        pings.updateClothing('Business')
    end))

table.insert(clothingActions, clothingPage:newAction()
    :title("Steampunk")
    :setTexture(textures['model.icons'],32,16, 16, 16)
    :onLeftClick(function()
        pings.updateClothing('Steampunk')
    end))

table.insert(clothingActions, clothingPage:newAction()
:title("Tropical")
    :setTexture(textures['model.icons'],48,16, 16, 16)
    :onLeftClick(function()
        pings.updateClothing('Tropical')
    end))

table.insert(clothingActions, clothingPage:newAction()
:title("Winter")
    :setTexture(textures['model.icons'],64,16, 16, 16)
    :onLeftClick(function()
        pings.updateClothing('Winter')
    end))

--SIZE ACTIONS
local sizePage = action_wheel:newPage('size')

table.insert(sizeActions, sizePage:newAction()
    :title("Increase all")
    :setTexture(textures['model.icons'],0,32, 16, 16)
    :onLeftClick(function()
        size.x = size.x+config.scaleChangeStep
        size.y = size.y+config.scaleChangeStep
        size.z = size.z+config.scaleChangeStep
        pings.updateSize()
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Increase X")
    :setTexture(textures['model.icons'],16,32, 16, 16)
    :onLeftClick(function()
        size.x = size.x+config.scaleChangeStep
        pings.updateSize()    
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Increase Y")
    :setTexture(textures['model.icons'],32,32, 16, 16)
    :onLeftClick(function()
        size.y = size.y+config.scaleChangeStep
        pings.updateSize()
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Increase Z")
    :setTexture(textures['model.icons'],48,32, 16, 16)
    :onLeftClick(function()
        size.z = size.z+config.scaleChangeStep
        pings.updateSize()
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Decrease Z")
    :setTexture(textures['model.icons'],112,32, 16, 16)
    :onLeftClick(function()
        size.z = size.z-config.scaleChangeStep
        pings.updateSize()
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Decrease Y")
    :setTexture(textures['model.icons'],96,32, 16, 16)
    :onLeftClick(function()
        size.y = size.y-config.scaleChangeStep
        pings.updateSize()
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Decrease X")
    :setTexture(textures['model.icons'],80,32, 16, 16)
    :onLeftClick(function()
        size.x = size.x-config.scaleChangeStep
        pings.updateSize()    
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Decrease All")
    :setTexture(textures['model.icons'],64,32, 16, 16)
    :onLeftClick(function()
        size.x = size.x-config.scaleChangeStep
        size.y = size.y-config.scaleChangeStep
        size.z = size.z-config.scaleChangeStep
        pings.updateSize()
    end))

table.insert(sizeActions, sizePage:newAction()
    :title("Reset all to 1")
    :setTexture(textures['model.icons'],128,32, 16, 16)
    :onLeftClick(function()
        size.x = 1
        size.y = 1
        size.z = 1
        pings.updateSize()
    end))