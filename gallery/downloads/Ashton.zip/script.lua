--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--Just some info
--If you want action wheel stuff just lmk and ill add it.
--  Currently, the actions that I've made before are player size changing, player texture changing, emotion changing (eye texture changing), and emotes made in blockbench.
--  I can also make an action to have the hair put up or not I think that would be cool
--Feel free to modify the blockbench file as you like, I wont be offended
--If you want a plush for the player head too just lmk it isnt that hard to do
--Also if you want to change the avatar description text, you can change it in the avatar.json file.

-- For if you wanna change stuff: (Which I recommend)
local config = {
    blinkLength = 1, --The amount of ticks the eyes stay closed while blinking | Default: 1
    blinkTryInterval = 60, --Every x ticks, the model will have a 1 in 2 chance to blink | Default: 60

    --For documentation on minecraft text JSON, look here: https://minecraft.wiki/w/Text_component_format
    displayNames = { --Dont forget you can use figura emojis in your names!
        list = { --Name that appears in the tablist.
            {
                text = "Ashton",
                bold = true,
                color = "#77b2d8"
            },
        },
        entity = { --Name that appears above the player.
            outline = { --Applies an outline to the text. This only works on the entity nameplate
                hasOutline = true,
                color = {255,255,255} --Must be an RGB value
            },
            value = {
                {
                    text = "Ashton",
                    bold = true,
                    color = "#77b2d8"
                }
            },
        },
        chat = { --Name that appears in chat. Uncomment the hoverEvent to have a custom tooltip when hovered on in chat.
            {
                text = "Ashton",
                bold = true,
                color = "#77b2d8",

                -- hoverEvent = {
                --     action = "show_text",
                --     contents = {
                --         text = "",
                --         extra = {
                --             {
                --                 text = "This is some cool hover text",
                --             },
                --         }
                --     }
                -- }
            },
        }
    }
}

-----DANGER ZONE-----

local ticks = 0
local isZooming = false
local zoomFactor = 5
local lastBlinkTick = 0
local isBlinking = false
local tail = {
    xOffset = 45,
    targetXOffset = 45,
    xConditionModifier = 0,

    yOffset = 0,
    layerYOffset = 0,

    wagSpeedMult = 1,
    wagSize = 1
}

function events.render(delta, context) 
    models.ashton.root.Body.Tail:setRot(
        vec(
        tail.xOffset,
        tail.yOffset,
        0)
    )

    models.ashton.root.Body.Tail.TailLayer:setRot(
        vec(
        0,
        tail.layerYOffset,
        0)
    )

    tail.yOffset = math.sin((ticks + delta) * tail.wagSpeedMult / 10) * 10 * tail.wagSize
    tail.layerYOffset = math.sin((ticks + delta + (50 + tail.wagSpeedMult)) * tail.wagSpeedMult / 10) * 2 * tail.wagSize

    if player:isGliding() or player:getPose() == "SWIMMING" then --Swimming / Flying
        tail.xConditionModifier = 25
        tail.wagSpeedMult = 1
        tail.wagSize = 1
    elseif player:isSprinting() then --Sprinting
        tail.xConditionModifier = -50
        tail.wagSpeedMult = 5
        tail.wagSize = 2
    elseif isWalking() then --Walking
        tail.xConditionModifier = -40
        tail.wagSpeedMult = 3
        tail.wagSize = 1.5
    elseif player:getVehicle() ~= nil then
        tail.xConditionModifier = -40
        tail.wagSpeedMult = 1
        tail.wagSize = 1
    else
        tail.xConditionModifier = 0
        tail.wagSpeedMult = 1
        tail.wagSize = 1
    end

    tail.targetXOffset = 45 + math.max(math.min(player:getVelocity()[2] * 100 + tail.xConditionModifier, 10), -75)
    tail.xOffset = tail.xOffset + (tail.targetXOffset - tail.xOffset) * 0.1
end

function events.tick()
    ticks = ticks + 1

    if(ticks % 60 == 0 and not isZooming) then --1 in 2 chance every three seconds to blink
        if (math.random(1, 2) == 1 and isBlinking == false) then
            lastBlinkTick = ticks
            isBlinking = true
            models.ashton.root.Head.EyeL:setVisible(false)
            models.ashton.root.Head.EyeR:setVisible(false)
        end
    end

    if(isBlinking and ticks - lastBlinkTick > config.blinkLength) then
        isBlinking = false
        models.ashton.root.Head.EyeL:setVisible(true)
        models.ashton.root.Head.EyeR:setVisible(true)
    end
end

function pings.updateNameplate()
    --Name that appears above the player
    nameplate.ENTITY:setText(toJson(config.displayNames.entity.value))
    nameplate.ENTITY:setOutline(config.displayNames.entity.outline.hasOutline)
    nameplate.ENTITY:setOutlineColor(config.displayNames.entity.outline.color[1] / 255, config.displayNames.entity.outline.color[2] / 255, config.displayNames.entity.outline.color[3] / 255)


    --Name that appears in the tablist
    nameplate.LIST:setText(toJson(config.displayNames.list))
    
    --Name that appears in chat
    nameplate.CHAT:setText(toJson(config.displayNames.chat))
end pings.updateNameplate()

function pings.setSquint(scale)
    models.ashton.root.Head.EyeR:setScale(vec(1, 1, scale))
    models.ashton.root.Head.EyeL:setScale(vec(1, 1, scale))
end

function events.KEY_PRESS(key, action) 
    if key == 67 then -- the keycode for the 'C', not kidding
        if action == 1 then --keydown
            isZooming = true
            pings.setSquint(zoomFactor)
        elseif action == 0 then --keyup
            isZooming = false
            pings.setSquint(1)
        end
    end
end

function events.mouse_scroll(delta)
    if(isZooming) then
        zoomFactor = math.max(zoomFactor + delta, 1)
        pings.setSquint(zoomFactor)
    end
end

function isWalking()
    return math.abs(player:getVelocity()[1]) >= 0.05 or math.abs(player:getVelocity()[3]) >= 0.05
end